#!/bin/sh

cleanup() {
    echo "SIGINT catch ctrl + c"
    pkill -f capture
    pkill -f dbwriter
    exit
}

trap cleanup INT

echo "start sniffer.py and dbwriter.py..."

while true; do
    if pgrep -f "/opt/rti_connext_dds-6.1.2/bin/" > /dev/null; then
        echo "RTI Routing Service is running, checking again in 10 seconds..."
        sleep 10
    else
        if ! pgrep -f ./capture > /dev/null; then
            echo "capture not running, starting it..."
            ./capture -i eno1 -p 1000 -c postgresql://postgres:admin@140.110.7.17:5433/postgres &
        fi

        if ! pgrep -f ./dbwriter > /dev/null; then
            echo "dbwriter not running, starting it..."
            ./dbwriter -t 60 -d postgresql://postgres:admin@140.110.7.17:5433/postgres &
        fi

        sleep 2
    fi
done

wait

